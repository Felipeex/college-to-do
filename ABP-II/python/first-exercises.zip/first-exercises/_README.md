https://stackoverflow.com/questions/51747961/how-to-use-2-index-variable-in-a-single-for-loop-in-python
https://stackoverflow.com/questions/66003883/how-to-delete-character-or-line-from-terminal-in-python
